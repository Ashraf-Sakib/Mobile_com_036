//
//  testAppApp.swift
//  testApp
//
//  Created by macos on 28/11/25.
//

import SwiftUI

@main
struct testAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
